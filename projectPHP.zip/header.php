<div class="header">
	<div class="container">
		<div class="row">
			<div class="col-md-6">
				<div class="judul animated bounceInDown">
					<img src="images/programming.png">
					<h2>Informatika 1 - 2018</h2>
				</div>
			</div>
			<div class="col-md-6">
				<div class="alamat animated bounceInRight">
					<h4>Telp : 085235662062</h4>
					<p>Jl Thamrin 35a - Madiun</p>
					<a href="http://twitter.com" target="_blank" title="Go to Twitter"><img src="images/twitter.png"></a>
					<a href="http://facebook.com" target="_blank" title="Go to Facebook"><img src="images/facebook.png"></a>
					<a href="http://instagram.com" target="_blank" title="Go to instagram"><img src="images/instagram.jpg"></a>
				</div>
			</div>
		</div>
	</div>
</div>